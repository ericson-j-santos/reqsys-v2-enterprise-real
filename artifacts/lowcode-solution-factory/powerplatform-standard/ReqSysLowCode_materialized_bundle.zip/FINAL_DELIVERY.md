# ReqSysLowCode Materialized Delivery

Data: 2026-07-02  
Ambiente materializado: `tieri (default)`  
URL: `https://orga258f260.crm2.dynamics.com/`

## Solutions exportadas do ambiente

| Arquivo | Conteudo | Uso |
| --- | --- | --- |
| `ReqSysLowCode_materialized_unmanaged.zip` | Solution principal com tabelas Dataverse, colunas, security roles e web resources de blueprint | DEV/sandbox |
| `ReqSysLowCode_materialized_managed.zip` | Versao managed da solution principal | Promocao controlada |
| `ReqSysLowCodeCopilot_unmanaged.zip` | Copilot Studio agent nativo `reqsys_ReqSysLowCodeCopilot` | DEV/sandbox |
| `ReqSysLowCodeCopilot_managed.zip` | Versao managed do Copilot | Promocao controlada |

## Componentes nativos criados

### Dataverse

Tabelas criadas na solution `ReqSysLowCode`:

- `reqsys_demanda`
- `reqsys_requisito`
- `reqsys_aprovacao`
- `reqsys_evidencia`
- `reqsys_release`

Colunas principais criadas conforme `materialization-evidence.json`. Lookups foram marcados como `skipped_lookup_p0` para evitar relacionamento inconsistente nesta primeira materializacao.

### Security roles

- `ReqSys Solicitante`
- `ReqSys Aprovador`
- `ReqSys Administrador Low-Code`
- `ReqSys Auditor`

### Web resources

- `reqsys_/lowcode/canvas.htm`
- `reqsys_/lowcode/manifest.htm`
- `reqsys_/lowcode/dataverse-schema.htm`
- `reqsys_/lowcode/powerautomate-flows.htm`
- `reqsys_/lowcode/copilot-security-alm.htm`

### Copilot Studio

Agente nativo criado:

- Nome: `ReqSysLowCode Copilot`
- Schema: `reqsys_ReqSysLowCodeCopilot`
- Agent ID: `a5705c8f-3bcb-47b2-9b72-b2d8beaf3e53`
- Solution: `reqsys_ReqSysLowCodeCopilot`

## Checker

`ReqSysLowCode_materialized_unmanaged.zip`:

```text
Critical: 0
High: 0
Medium: 0
Low: 0
Informational: 0
```

`ReqSysLowCodeCopilot_unmanaged.zip`:

```text
Critical: 0
High: 0
Medium: 0
Low: 0
Informational: 0
```

## Pendencias tecnicas honestas

Canvas App e Power Automate flows foram preservados como contratos/web resources dentro da solution principal. Eles nao foram criados como componentes nativos nesta rodada porque:

- `pac canvas create` exige `connector-id` ou `connector-display-name` para gerar `.msapp`.
- Power Automate flow nativo exige definition/connection references validas para importacao segura.

Esses dois itens estao prontos como contrato governado dentro da solution e podem ser materializados na proxima etapa com:

- gerador `.msapp` valido ou app criado no Power Apps e reexportado;
- flow definitions reais com connection references por ambiente.
